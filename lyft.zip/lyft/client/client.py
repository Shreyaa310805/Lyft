import requests
import sys

def ping_server(base_url):
    resp = requests.post(f"{base_url}/ping", json={"data": "ping"})
    print("Ping response:", resp.json())

def submit_ride_request(base_url, source, dest, user_id):
    payload = {
        "source_location": source,
        "dest_location": dest,
        "user_id": user_id
    }
    resp = requests.post(f"{base_url}/ride-request", json=payload)
    print("Ride request response:", resp.json())

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python client.py [ping|ride] [args...]")
        sys.exit(1)
    base_url = "http://127.0.0.1:8000"
    if sys.argv[1] == "ping":
        ping_server(base_url)
    elif sys.argv[1] == "ride":
        if len(sys.argv) == 5:
            source, dest, user_id = sys.argv[2], sys.argv[3], sys.argv[4]
        else:
            source = input("Enter source location: ")
            dest = input("Enter destination location: ")
            user_id = input("Enter user_id: ")
        submit_ride_request(base_url, source, dest, user_id)
    else:
        print("Unknown command")
