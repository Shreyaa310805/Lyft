from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

app = FastAPI()

class PingRequest(BaseModel):
    data: str

class RideRequest(BaseModel):
    source_location: str
    dest_location: str
    user_id: str

@app.post("/ping")
async def ping(request: PingRequest):
    if request.data == "ping":
        return {"response": "pong"}
    return JSONResponse(status_code=400, content={"error": "Invalid data"})

@app.post("/ride-request")
async def ride_request(ride: RideRequest):
    # Here, you would store the data in Postgres
    print(f"We will store this data in Postgres now: {ride.dict()}")
    return {"message": "Ride request received", "data": ride.dict()}
