# Ride Request Backend (Python FastAPI)

This project is a simple backend server to accept ride requests.

## Features
- API endpoint: **POST /rides**
- Input: `source_location`, `dest_location`, `user_id`
- Server prints details in terminal:
  ```
  --- Ride Request Received ---
  Source: ...
  Destination: ...
  User ID: ...
  We will store this data in Postgres now
  ```
- Server responds with JSON containing the same data.

## How to Run
1. Create virtualenv  
   ```
   python -m venv venv
   ```
2. Activate it  
   - Windows (PowerShell):  
     ```
     .\venv\Scripts\Activate.ps1
     ```
   - Mac/Linux:  
     ```
     source venv/bin/activate
     ```
3. Install dependencies  
   ```
   pip install -r requirements.txt
   ```
4. Run server  
   ```
   uvicorn server.main:app --reload
   ```

Now use curl or Postman to send requests:
```
curl -X POST http://127.0.0.1:8000/rides \
     -H "Content-Type: application/json" \
     -d '{"source_location":"Koramangala","dest_location":"Indiranagar","user_id":"u_101"}'
```

## Expected Output
### Terminal (backend):
```
--- Ride Request Received ---
Source: Koramangala
Destination: Indiranagar
User ID: u_101
We will store this data in Postgres now
```

### JSON Response:
```json
{
  "message": "We will store this data in Postgres now",
  "data": {
    "source_location": "Koramangala",
    "dest_location": "Indiranagar",
    "user_id": "u_101"
  }
}
```
