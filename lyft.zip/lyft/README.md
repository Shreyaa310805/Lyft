# Mini Uber Project

This project is a minimal Uber-like system using FastAPI (Python) for the server and a Python client for API interaction.

## Structure
- `server/`: FastAPI backend
- `client/`: Python client for API calls

## Server Setup
1. Navigate to the `server` directory:
   ```sh
   cd server
   ```
2. Install dependencies (already installed if you followed setup):
   ```sh
   pip install -r requirements.txt
   ```
3. Run the server:
   ```sh
   uvicorn main:app --reload
   ```

## Client Usage
1. Navigate to the `client` directory:
   ```sh
   cd ../client
   ```
2. Install dependencies (already installed if you followed setup):
   ```sh
   pip install -r requirements.txt
   ```
3. Ping the server:
   ```sh
   python client.py ping
   ```
4. Submit a ride request:
   ```sh
   python client.py ride "source_location" "dest_location" "user_id"
   ```

## API Endpoints
- `POST /ping` with `{ "data": "ping" }` returns `{ "response": "pong" }`
- `POST /ride-request` with `{ "source_location": ..., "dest_location": ..., "user_id": ... }` prints a message about storing in Postgres and returns the data.

## Notes
- Data is not actually stored in Postgres; a print statement simulates this.
- You can also use `curl` to interact with the server endpoints.
