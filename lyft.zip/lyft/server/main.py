from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Ride Request Server")

class RideCreate(BaseModel):
    source_location: str
    dest_location: str
    user_id: str

@app.post("/rides")
async def create_ride(ride: RideCreate):
    # Print in terminal
    print("\n--- Ride Request Received ---")
    print(f"Source: {ride.source_location}")
    print(f"Destination: {ride.dest_location}")
    print(f"User ID: {ride.user_id}")
    print("We will store this data in Postgres now")

    # Return JSON response
    return {
        "message": "We will store this data in Postgres now",
        "data": ride.dict()
    }
